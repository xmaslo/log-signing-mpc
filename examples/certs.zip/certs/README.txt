This is EXAMPLE ONLY, do NOT use for production. ALWAYS generate your OWN keys!
